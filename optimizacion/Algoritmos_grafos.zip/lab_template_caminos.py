"""
Laboratorio: Caminos mínimos — Dijkstra y Bellman-Ford
UCM — Flujos en Redes (3.º Matemáticas)

Completad las dos funciones. No modificar helpers_caminos.py.
Ejecutad test_env_caminos.py para comprobar los resultados.
"""

from typing import Dict, List, Tuple, Optional
from helpers_caminos import reconstruct_path, get_all_nodes


# ─────────────────────────────────────────────────────────────────
# FUNCIÓN 1: DIJKSTRA
# ─────────────────────────────────────────────────────────────────

def dijkstra(
        graph: Dict[str, Dict[str, float]],
        source: str,
        target: str,
) -> dict:

    V = set(get_all_nodes(graph))

    # Inicializamos vecinos de source
    dist = {v: float('inf') for v in V}
    prev = {v: None for v in V}
    dist[source] = 0

    for j, w in graph[source].items():
        dist[j] = w
        prev[j] = source

    P = {source}  # Creamos los conjuntos P (permanentes) y T (transitorios)
    T = V - P
    steps = []

    # Registro inicial: solo el origen es permanente
    steps.append({
        'current': source,
        'distances': dict(dist),
        'predecessors': dict(prev),
        'visited': set(P)
    })

    while T:
        k = min(T, key=lambda j: dist[j])  # Seleccionamos el mínimo, lo añadimos al conjunto de vértices permanentes y lo eliminamos de los transitorios

        P.add(k)
        T.discard(k)

        # Registramos el paso haciendo copias
        steps.append({
            'current': k,
            'distances': dict(dist),
            'predecessors': dict(prev),
            'visited': set(P)
        })

        if k == target:
            break

        for j, w in graph[k].items():  # Aquí analizamos los arcos que salen de k para ver si se pueden actualizar las distancias
            if j in T and dist[k] + w < dist[j]:
                dist[j] = dist[k] + w
                prev[j] = k

    path = reconstruct_path(prev, source, target)

    return {
        'distances': dist,
        'predecessors': prev,
        'path': path,
        'steps': steps
    }


# ─────────────────────────────────────────────────────────────────
# FUNCIÓN 2: BELLMAN-FORD
# ─────────────────────────────────────────────────────────────────

def bellman_ford(
        graph: Dict[str, Dict[str, float]],
        source: str,
        target: str,
) -> dict:

    V = set(get_all_nodes(graph))
    n = len(V)

    # Inicializamos vecinos de source (caminos de longitud 1)
    dist = {v: float('inf') for v in V}
    prev = {v: None for v in V}
    dist[source] = 0

    for j, w in graph.get(source, {}).items():
        dist[j] = w
        prev[j] = source

    steps = []

    for t in range(1, n-1):   # Queremos ver t = 1,..., n-2
        new_dist = dict(dist)  # Hacemos una copia de la iteración anterior
        updated_edges = []
        changed = False

        # Recorremos todos los arcos del grafo
        for k in graph:
            for j, w in graph[k].items():
                if dist[k] + w < new_dist[j]:
                    new_dist[j] = dist[k] + w
                    prev[j] = k
                    updated_edges.append((k, j))
                    changed = True
        dist = new_dist

        steps.append({
            'iteration': t,
            'distances': dict(dist),
            'predecessors': dict(prev),
            'updated_edges': updated_edges
        })

        if not changed:
            break

    # Queremos detectar ciclos negativos si los hay
    has_negative_cycle = False
    for k in graph:
        for j, w in graph[k].items():
            if dist[k] + w < dist[j]:
                has_negative_cycle = True
                break
        if has_negative_cycle:
            break

    path = None if has_negative_cycle else reconstruct_path(prev, source, target)
    return {
        'distances': dist,
        'predecessors': prev,
        'path': path,
        'steps': steps,
        'has_negative_cycle': has_negative_cycle
    }


# ─────────────────────────────────────────────────────────────────
# REFLEXIÓN (responder aquí como comentario)
# ─────────────────────────────────────────────────────────────────
#
# P1. Ejecutad Dijkstra sobre el Problema 2 (arcos negativos).
#     ¿Qué camino devuelve y con qué coste? ¿Por qué falla?
#     ¿Qué nodo se marca como permanente prematuramente?
#
# P1: Dijkstra devuelve el camino Madrid -> Guadalajara -> Cuenca -> Valencia,
#     que tiene coste 11, comparado con el camino óptimo real que tiene coste 9.
#     El algoritmo en este caso falla y nos devuelve este camino que no es el
#     mejor porque hay un arco negativo: Toledo -> Guadalajara, que tiene coste -3.
#     El algoritmo toma Guadalajara como vértice permanente porque es el de menor
#     coste (tiene coste 2), pero no tiene en cuenta la posibilidad de tomar el
#     camino Madrid -> Toledo -> Guadalajara, que tiene coste 0. Por tanto falla
#     porque añade Guadalajara antes de tiempo y no se puede volver a considerar.
#
# P2. Comparad el número de comprobaciones de arcos de Dijkstra
#     y Bellman-Ford en el Problema 1. ¿Por qué Dijkstra necesita
#     menos? Relacionad con O(n^2) frente a O(n^3).
#
# P2: Dijkstra realiza menos comprobaciones porque solo comprueba los arcos desde el nodo
#     seleccionado en cada iteración, y cada nodo se procesa una sola vez. En cambio,
#     Bellman-Ford recorre todos los arcos en cada pasada, repitiendo este proceso para
#     considerar caminos con hasta n−1 arcos en el peor caso. Esto hace que el número de
#     comprobaciones de Bellman-Ford sea mucho mayor. En resumen, Dijkstra simplemente revisa
#     vecinos en cada iteración mientras que Bellman-Ford realiza varias pasadas completas
#     sobre todos los arcos del grafo. Por tanto, esto afecta a la complejidad de ambos
#     métodos: Dijkstra es O(n^2), mientras que Bellman-Ford es O(n^3). Por tanto, Dijkstra
#     suele ser más rápido en grafos sin arcos con coste negativo.
#
# P3. En el Problema 3, la transformación w = -ln(r) exige r > 0.
#     ¿Es razonable? Si Bellman-Ford no detecta ciclo negativo,
#     ¿significa que no hay ninguna oportunidad de beneficio, o solo
#     que no hay arbitraje sin riesgo? Razonad la diferencia.
#
# P3: Sí que es razonable, porque las tasas de cambio son siempre positivas. Si Bellman-Ford no detecta
#     un ciclo negativo (w_ciclo ≥ 0), significa que no existe ningún ciclo en el que el producto de las
#     tasas de cambio sea mayor que 1 (porque -ln(producto) ≥ 0 y por tanto, producto ≤ 1).
#     Por tanto, no hay oportunidades de arbitraje sin riesgo, ya que no es posible empezar en una divisa
#     y volver a la misma obteniendo un beneficio seguro. Este tipo de beneficio es sin riesgo porque
#     corresponde a un ciclo cerrado, que no depende de la evolución futura del mercado. Sin embargo, si
#     que pueden existir oportunidades de beneficio con riesgo, ya que por ejemplo podrían darse ganancias
#     dependiendo de la evolución futura de las tasas, pero sin garantía de beneficio.
#
# P4. ¿Qué ocurre si aplicáis Bellman-Ford al Problema 1?
#     ¿Resultado correcto? ¿Cuántas pasadas antes de la convergencia
#     anticipada vs. iteraciones de Dijkstra?
#
# P4: Bellman-Ford también devuelve el resultado correcto del problema 1 (distancia 14, camino
#     Moncloa -> Arguelles -> Chamberi -> Salamanca -> Retiro). Necesita 4 pasadas completas para
#     converger (necesita encontrar caminos de longitud 1, luego 2, luego 3 y finalmente 4 ya que
#     en los de distancia 5 ya no hay cambios con respecto a los de distancia 4 y por tanto se para ahí).
#     Dijkstra realiza 7 iteraciones (pasa por Arguelles, Tetuán, Chamberí, Chamartín, Salamanca,
#     Sol y finalmente llega al Retiro, ya que se para ahí ya que has llegado al destino).
#
# OPCIONAL. Suponed que cada conversión de divisas tiene una comisión
# fija de c euros. ¿Cómo modificaríais los pesos? ¿Sigue siendo
# válida la transformación logarítmica? Si no, proponed alternativa.
#
# OPCIONAL: Al añadir ahora una comisión fija de c euros, en lugar de ser simplemente un producto
#           de divisas, ahora es una mezcla de multiplicaciones y restas (es decir, tenemos algo así:
#           dinero_nuevo = dinero_actual * r - c). Por tanto, la transformación con logaritmo ya no
#           funciona porque ya no se pueden separar los términos en sumas al no ser solo multiplicaciones.
#           Por esto, el problema ya no puede modelarse como un problema estándar de camino mínimo con
#           suma de pesos. Una propuesta alternativa es que en lugar de trabajar con el objetivo de
#           minimizar pesos se podría buscar maximizar el dinero. Para esto se podría entender el grafo
#           como las divisas en los vértices y en cada arista se da la transformación de dinero:
#           dinero = dinero * r - c. Así, con Bellman-Ford se podrían detectar ciclos que permitan
#           aumentar indefinidamente el dinero (así hay posibilidad de arbitraje).
