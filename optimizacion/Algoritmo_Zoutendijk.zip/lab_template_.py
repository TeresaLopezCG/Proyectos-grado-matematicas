"""
Laboratorio: Algoritmo de Zoutendijk — UCM Optimización
Completad las cuatro funciones. No modificar helpers.py.
"""

import numpy as np
from typing import Callable, List, Tuple
from helpers import solve_direction_lp, line_search, check_feasibility


# ─────────────────────────────────────────────────────────────────
# FUNCIÓN 1
# ─────────────────────────────────────────────────────────────────

def compute_lambda_max(
        x: np.ndarray,
        d: np.ndarray,
        g_funcs: List[Callable],
        tol: float = 1e-10
) -> float:
    lambda_max = np.inf  # Le asignamos inicialmente +∞

    for g in g_funcs:

        if g(x) > 0:
            raise ValueError("x no es factible")

        # Hacemos la búsqueda exponencial
        lo = 0.0  # Los tomamos como números reales
        hi = 1.0
        while g(x + hi * d) <= 0:
            lo = hi
            hi = 2.0 * hi
            if hi > 1e15:  # Esta restricción no la limita
                lo = np.inf
                break

        if lo == np.inf:  # Hacemos que pase entonces a la siguiente restricción
            continue

        # Hacemos la bisección
        while hi - lo > tol:
            mid = 0.5 * (lo + hi)
            if g(x + mid * d) <= 0:
                lo = mid
            else:
                hi = mid

        lambda_max = min(lambda_max, lo)

    return lambda_max


# ─────────────────────────────────────────────────────────────────
# FUNCIÓN 2
# ─────────────────────────────────────────────────────────────────

def identify_active_constraints(
        x: np.ndarray,
        g_funcs: List[Callable],
        tol: float = 1e-6
) -> List[int]:
    activas = []
    for i, g in enumerate(g_funcs):
        if g(x) >= -tol:
            activas.append(i)

    return activas


# ─────────────────────────────────────────────────────────────────
# FUNCIÓN 3
# ─────────────────────────────────────────────────────────────────

def zoutendijk_step(
        x: np.ndarray,
        f: Callable,
        grad_f: Callable,
        g_funcs: List[Callable],
        grad_g_funcs: List[Callable],
        tol_active: float = 1e-6
) -> Tuple[bool, np.ndarray, dict]:

    active = identify_active_constraints(x, g_funcs, tol_active)
    grad_f = grad_f(x)
    grads_activos = [grad_g_funcs[i](x) for i in active]

    # Resolvemos LP
    z, d = solve_direction_lp(grad_f, grads_activos)

    # Condición de parada
    if z >= -tol_active:
        info = {
            "z": z,
            "d": d,
            "lambda": 0.0,
            "f_new": f(x),
            "active": active
        }
        return True, x, info

    # Calculamos ahora el máximo paso factible
    lambda_max = compute_lambda_max(x, d, g_funcs)
    # Buscamos el mejor lambda
    mejor_lam = line_search(f, x, d, lambda_max)

    x_new = x + mejor_lam * d

    info = {
        "z": z,
        "d": d,
        "lambda": mejor_lam,
        "f_new": f(x_new),
        "active": active
    }

    return False, x_new, info


# ─────────────────────────────────────────────────────────────────
# FUNCIÓN 4
# ─────────────────────────────────────────────────────────────────

def zoutendijk(
        f: Callable,
        grad_f: Callable,
        g_funcs: List[Callable],
        grad_g_funcs: List[Callable],
        x0: np.ndarray,
        tol: float = 1e-6,
        max_iter: int = 500
) -> dict:

    if not check_feasibility(x0, g_funcs):
        raise ValueError("x0 no es factible")

    x = x0.copy()

    history = []
    x_history = [x.copy()]

    converged = False

    for k in range(max_iter):

        converged, x_new, info = zoutendijk_step(x, f, grad_f, g_funcs, grad_g_funcs)
        history.append(info)

        x = x_new
        x_history.append(x.copy())

        if converged:
            break

        if np.linalg.norm(info["d"]) < tol:
            converged = True
            break

    result = {
        "x": x,
        "f": f(x),
        "iterations": len(history),
        "converged": converged,
        "history": history,
        "x_history": x_history
    }

    return result

# ─────────────────────────────────────────────────────────────────
# REFLEXIÓN (responder aquí como comentario)
# ─────────────────────────────────────────────────────────────────
#
# P1. La barrera logarítmica exige x0 estrictamente interior (gi(x0) < 0).
#     Zoutendijk solo pide gi(x0) <= 0. ¿Qué ocurre si x0 está en la frontera?
#     ¿Es un problema para Zoutendijk? ¿Por qué la barrera no puede permitírselo?
#
# P2. La restricción dj ∈ [-1,1] (donde dj es la j-ésima componente de d)
#     no aparece en la formulación teórica. ¿Por qué es necesaria en la práctica?
#     ¿Qué degeneración ocurre sin ella?
#
# P3. Comparando los tres métodos en los tres problemas: ¿dónde es Zoutendijk
#     más lento que penalización? ¿Hay algún caso donde es más rápido?
#     Propón una hipótesis que explique ambas observaciones.


# P1: Si x0 está en la frontera no es un problema para Zoutendijk porque en ese caso, gi(x0) = 0
#     entraría dentro del conjunto de restricciones activas y luego, en el subproblema lineal
#     del algoritmo se incluye con la condición de que grad(gi(x0)^T)*d <= z, asegurando así
#     que la dirección de búsqueda d no viole dicha restricción activa. En cambio, la barrera no
#     puede permitirse que gi(x0)=0 ya que en su función objetivo aparece el término
#     -μ*log(-gi(x)), el cual no está definido para x=0, haciendo que la función explote a infinito
#     y que no se pueda inicializar el algoritmo.

# P2: Sin esa cota de que dj esté en [-1,1], el problema lineal sería no acotado, ya que
#     si existe alguna dirección de descenso factible, es decir, que hace que grad(f^T)*d<=z, y
#     grad(gi^T)<=z, entonces podríamos escalar esa dirección arbitrariamente porque cualquier
#     múltiplo αd con α>0 también sería una dirección factible y haría a la z cada vez más y más
#     negativa, haciendo que tienda a -infinito. Por tanto, esta cota de [-1,1] lo que hace es
#     que el problema sea acotado y que así si conseguimos un z más negativo sea porque realmente
#     hemos encontrado una dirección mejor.

# P3: Zoutendijk es más lento que la penalización en problemas donde el óptimo está en el interior,
#     como en el P3 de test_env por ejemplo, ya que mientras no haya restricciones activas,
#     Zoutendijk sigue resolviendo un subproblema lineal (LP) en cada iteración, y este tiene un
#     coste computacional elevado. En cambio, la penalización simplemente hace un problema sin
#     restricciones, por lo que suele ser más rápido en estos casos.
#     Zoutendijk suele ser más rápido cuando el óptimo se encuentra en la frontera ya que el método
#     incorpora directamente las restricciones activas en el cálculo de la dirección d que buscamos
#     y esto hace que se mueva rápidamente sobre la frontera correcta.
#     Por tanto, la hipótesis que sacamos de esto es que Zoutendijk es más rápido cuando la solución
#     está determinada por restricciones activas y más lento cuando la soluciónn está en el interior
#     del conjunto factible.


# OPCIONAL. El algoritmo está formulado para restricciones de desigualdad.
# Suponed que el problema incluye también h(x) = 0.
# (a) ¿Cómo incorporaríais la igualdad sin modificar ninguna función implementada?
# (b) ¿Qué implicación tiene esa transformación sobre el conjunto I en cada iteración?
# (c) ¿Qué efecto tiene sobre compute_lambda_max cuando h(x^{(k)}) = 0?
#
# OPCIONAL:
#     (a) Una restricción de igualdad h(x)=0 también se puede ver como las dos inecuaciones
#     h(x)<=0 y h(x)>=0 (-h(x)<=0). Así, incluimos estas dos inecuaciones en el conjunto
#     de restricciones gi(x) de desigualdad.

#     (b) Lo que implica esa transformación es que cuando tengamos h(x)=0 entonces necesariamente
#     tendremos que las dos nuevas restricciones tendrán que estar activas simultáneamente.

#     (c) Cuando se satisface que h(x^k) = 0 y tenemos una dirección de búsqueda d^k,entonces
#     para la primera desigualdad tendríamos la condición h(x^k + λd^k) <= 0, y para la segunda
#     tendríamos h(x^k + λd^k) >= 0. Esto implica que tendríamos h(x^k + λd^k) = 0. Es decir,
#     ahora el λ lo debemos elegir de tal forma que la función h se mantenga valiendo 0 para que
#     así las dos restricciones se sigan cumpliendo.
