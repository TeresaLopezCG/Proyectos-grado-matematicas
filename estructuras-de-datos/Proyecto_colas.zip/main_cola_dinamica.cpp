#include <iostream>
#include "cola_dinamica.h"


int main (int argc, char * const argv[]) {
	
	try {
	
		TColaDinamica<char> cola;
	
		cola.ponDetras('a');
		cola.ponDetras('b');
		cola.ponDetras('c');
		cola.ponDetras('d');
	
		cola.escribe();
	
		cola.ponDetras('e');
	
		cola.escribe();
	
		cola.ponDetras('f');
	
		cola.escribe();
	
		cola.ponDetras('g');
	
		cola.escribe();
	
		cout << endl;
		cout << "El primer elemento de la cola es: " << cola.primero();
		cout << endl;
	
		cola.quitaPrim();
	
		cola.escribe();
	
		cout << endl;
		cout << "El primer elemento de la cola es: " << cola.primero();
		cout << endl;
	
		cout << endl;
		if ( cola.esVacio() ) cout << "La cola SI esta vacia";
		else cout << "La cola NO esta vacia";
		cout << endl;
	
		cout << endl;
		
		
		// PRUEBA DE LOS EJERCICIOS DE LA HOJA 3
		
		TColaDinamica<char> cola1;
		TColaDinamica<char> cola2;
		
		cola.ponDetras('h');
		cola.ponDetras('i');
		cola.escribe();
		
		cola.dividecola(cola1, cola2);
		
		cout << "La primera cola de la division es: " << endl;
		cola1.escribe();
		cout << "La segunda cola de la division es: " << endl;
		cola2.escribe();
		
		cout << endl;
		
		
		
		TColaDinamica<int> cola_ent;
		
		cola_ent.ponDetras(8);
		cola_ent.ponDetras(-4);
		cola_ent.ponDetras(6);
		cola_ent.ponDetras(2);
		cola_ent.ponDetras(0);
		cola_ent.ponDetras(2);
		cola_ent.ponDetras(0);
		cola_ent.ponDetras(3);
		cola_ent.ponDetras(-8);
		cola_ent.ponDetras(0);
		cola_ent.ponDetras(9);
		cola_ent.ponDetras(-1);
		cola_ent.ponDetras(2);
		cola_ent.ponDetras(0);
		cola_ent.ponDetras(5);
		
		cout << "La cola que voy a colapsar es: " << endl;
		cola_ent.escribe();
		
		cout << "Este es el resultado de colapsar dicha cola: " << endl;
		cola_ent.colapsar();
		cola_ent.escribe();
				
	}
	catch( EAccesoIndebido e ) {
		cout << e.mensaje( );
	}
	
    return 0;
	
}
