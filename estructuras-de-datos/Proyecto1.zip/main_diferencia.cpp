#include <iostream>
#include "Conjunto.h"

using namespace std;


int main(int argc, char* argv[]){
	
    int N, elem, card1, card2;

    
    cout << "Introduce el numero de parejas de conjuntos que quieras probar: \n ";
    
    cin >> N;
    
    	for (int i = 0; i < N; i++){
    		
    		TCjto<int> cjto1, cjto2;
    		
    		cout << "Introduce el cardinal del primer conjunto: \n ";
    		cin >> card1;
    		
    		cout << "Introduce el cardinal del segundo conjunto: \n ";
        	cin >> card2;
        	
        	cout << "Introduce los elementos del primer conjunto: \n ";
        	
        	for (int j = 0; j < card1; j++){
        		
        		cin >> elem;
        		cjto1.pon(elem);
        		
			}
        	
        	cout << "Introduce los elementos del segundo conjunto: \n ";
        	
        	for (int j = 0; j < card2; j++){
        		
        		cin >> elem;
        		cjto2.pon(elem);
        		
			}
        	
        cjto1.diferencia(cjto2);
        cout << "Diferencia: " << cjto1 << endl;
			
    	}
    	
}