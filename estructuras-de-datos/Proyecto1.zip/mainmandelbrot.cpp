#include <iostream>
#include "Complejo.h"

using namespace std;

bool mandelbrot(MiComplejo &c, int &iteraciones){   // O(n) , donde n es el numero de iteraciones
	
	MiComplejo base(0,0);
	for (int i=0; i < iteraciones && base.modulo() <= 2; i++){
		
		base.producto(base);
		base.suma(c);
		
	}
	
	return base.modulo() <= 2;
	
}


int main(int argc, char* argv[]){
    int num_casos;
    cout << "Introduce el numero de casos que quieras probar:";
    cin >> num_casos;
    for (int i = 0; i < num_casos; ++i){
        float parte_re;
        float parte_im;
        int num_iteraciones;
        cout << "Introduce, en orden, la parte real, la parte imaginaria y el numero de iteraciones: ";
        cin >> parte_re >> parte_im >> num_iteraciones;
        MiComplejo c(parte_re, parte_im);
        cout << (mandelbrot(c, num_iteraciones) ? "SI" : "NO") << endl;
    }
}



