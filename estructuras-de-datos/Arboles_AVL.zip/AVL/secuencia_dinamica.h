#ifndef secuencia_dinamicaH
#define secuencia_dinamicaH


/*
 
 
 especificacion SECUENCIAS[ELEM]
 
 usa LISTAS[ELEM], BOOLEANOS
 
 tipos secuencia
 
 operaciones
 
	nuevo    :                 -->   secuencia 
	inserta  : secuencia elem  -->   secuencia
    borra    : secuencia       -/->  secuencia
    actual   : secuencia       -/->  elem                 
    avanza   : secuencia       -/->  secuencia             
    reinicia : secuencia       -->   secuencia          
    esVacio  : secuencia       -->   bool                
    esFin    : secuencia       -->   bool                   
 
  operaciones privadas
 
    sec      : lista lista     -->   secuencia    { constructora }
    piz      : secuencia       -->   lista   
    pdr      : secuencia       -->   lista 
    cont     : secuencia       -->   lista 
 
 variables
 
	x        : elem
	s        : secuencia
	iz, dr   : lista
	
 ecuaciones

    nuevo                              = sec(vacio, vacio)
 
    inserta(sec(iz, dr), x)            = sec(ponDetras(iz, x), dr)
 
    esFin(sec(iz, dr))                 = esVacio(dr)
 
	borra(s)                           = error                            <==  esFin(s)
    borra(sec(iz, ponDelante(x, dr)))  = sec(iz, dr)
 
	actual(s)                          = error                            <==  esFin(s)
    actual(sec(iz, ponDelante(x, dr))) = x
 
    avanza(s)                          = error                            <==  esFin(s)
    avanza(sec(iz, ponDelante(x, dr))) = sec(ponDetras(iz, x), dr)
 
    reinicia(sec(iz, dr))              = sec(vacio, concatena(iz, dr))
 
    esVacio(sec(iz, dr))               = esVacio(iz) /\ esVacio(dr)
 
    piz(sec(iz, dr))                   = iz
 
    pdr(sec(iz, dr))                   = dr
 
    cont(sec(iz, dr))                  = concatena(iz, dr)

 
 fespecificacion

 
*/


#include <iostream>
#include <string>

using namespace std;



// Tratamiento de excepciones


class EDesbordamiento {
	
  public:
	
    EDesbordamiento( string mensaje = "" ) : _mensaje(mensaje) { };
	
    string mensaje ( ) {
		
		return _mensaje;
		
    };
	
  private:
	
    string _mensaje;
	
};


class EAccesoIndebido {
	
  public:
	
    EAccesoIndebido( string mensaje = "" ) : _mensaje(mensaje) { };
	
    string mensaje ( ) {
		
		return _mensaje;
		
    };
	
  private:
	
    string _mensaje;
	
};


class EClaveErronea {

  public:
	
    EClaveErronea( string mensaje = "" ) : _mensaje(mensaje) { };
	
    string mensaje ( ) {
		
		return _mensaje;
		
    };
	
  private:
	
    string _mensaje;
	
};



// Clase de los nodos de la secuencia


template <class TElem>
class TSecuenciaDinamica;


template <class TElem>
class TNodoSecuencia {
	
  private:
	
    TElem _elem;
    TNodoSecuencia<TElem>* _sig;
	
    TNodoSecuencia( );
    TNodoSecuencia( TElem, TNodoSecuencia<TElem>* = 0 );
	
  public:
	
    TElem elem( );
    TNodoSecuencia<TElem>* sig( );
	
    friend class TSecuenciaDinamica<TElem>;
	
};



// Clase de las secuencias


template <class TElem>
class TSecuenciaDinamica {
	
	
  public:

  // Constructora
	
     TSecuenciaDinamica( );
     // O(1) sobre tipos predefinidos
     

  // Operaciones de las secuencias
	
     void inserta( TElem );
     // Pre: true
     // Post: Se anade un elemento a la secuencia, delante del punto de interes
     // O(1) sobre tipos predefinidos

     void borra( ); // throw ( EAccesoIndebido );
     // Pre: ! esFin( )
     // Post: Elimina el elemento que esta detras del punto de interes
     // Lanza la excepcion "EAccesoIndebido" si el punto de interes esta al final
     // O(1) sobre tipos predefinidos

     TElem actual( ); // throw ( EAccesoIndebido );
     // Pre: ! esFin( )
     // Post: Devuelve el elemento a continuacion del punto de interes
     // Lanza la excepcion "EAccesoIndebido" si el punto de interes esta al final
     // O(1)

     void avanza( ); // throw ( EAccesoIndebido );
     // Pre: ! esFin( )
     // Post: Avanza una posicion el punto de interes
     // Lanza la excepcion "EAccesoIndebido" si el punto de interes esta al final
     // O(1)

     void reinicia( );
     // Pre: true
     // Post: Coloca el punto de interes al principio de la secuencia
     // O(1)

     bool esFin( );
     // Pre: true
     // Post: Determina si el punto de interes esta al final de la secuencia
     // O(1)

     bool esVacio( );
     // Pre: true
     // Post: Determina si la secuencia esta vacia
     // O(1)

	
  // Escritura
	
     void escribe( );
	

  private:
	
  // Variables privadas
	
     TNodoSecuencia<TElem> *_pri, *_ant;

	
};



//---------------------------------------------------------------------------
// IMPLEMENTACION
//---------------------------------------------------------------------------


  // Clase de los nodos

    // Es necesaria una constructora sin parametros (sin elem) para poder
    // construir el nodo fantasma. El campo _elem de ese nodo contendra
    // basura si se trata de un tipo primitivo o el resultado de llamar
    // a la constructora por defecto si no lo es.


    template <class TElem>
    TNodoSecuencia<TElem>::TNodoSecuencia( ) : 
	  _sig(0) {
    };


    template <class TElem>
    TNodoSecuencia<TElem>::TNodoSecuencia( TElem elem, TNodoSecuencia<TElem>* sig ) :
      _elem(elem), _sig(sig) {
    };


    template <class TElem>
    TElem TNodoSecuencia<TElem>::elem( ) {
		
      return _elem;
		
    }


    template <class TElem>
    TNodoSecuencia<TElem>* TNodoSecuencia<TElem>::sig( ) {
		
      return _sig;
		
    }


  // Constructora

     template <class TElem>
     TSecuenciaDinamica<TElem>::TSecuenciaDinamica( ) {
		 
       _pri = _ant = new TNodoSecuencia<TElem>( );
		 
     };


  // Operaciones de las secuencias

     template <class TElem>
     void TSecuenciaDinamica<TElem>::inserta( TElem elem ) {
		 
       TNodoSecuencia<TElem>* nuevo = new TNodoSecuencia<TElem> ( elem, _ant -> sig( ) );
		 
       _ant -> _sig = nuevo;
		 
       _ant = nuevo;
		 
     };


     template <class TElem>
     TElem TSecuenciaDinamica<TElem>::actual( ) // throw ( EAccesoIndebido ) 
	 {
		 
       if( esFin( ) )
		   
         throw EAccesoIndebido( "Error: el punto de interes este al final" );
		 
       return _ant -> sig( ) -> elem( );
		 
     };


     template <class TElem>
     void TSecuenciaDinamica<TElem>::borra( ) // throw ( EAccesoIndebido ) 
	 {
		 
       if( esFin( ) )
		   
         throw EAccesoIndebido( "Error: el punto de interes esta al final" );
		 
       TNodoSecuencia<TElem>* act = _ant -> sig( );
		 
       _ant -> _sig = act -> sig( );
		 
       delete act;
		 
     };


     template <class TElem>
     void TSecuenciaDinamica<TElem>::avanza( ) // throw ( EAccesoIndebido ) 
	 {
		 
       if( esFin( ) )
		   
         throw EAccesoIndebido( "Error: el punto de interes esta al final" );
		 
       _ant = _ant -> sig( );
		 
     };


     template <class TElem>
     void TSecuenciaDinamica<TElem>::reinicia( ) {
		 
       _ant = _pri;
		 
     };


     template <class TElem>
     bool TSecuenciaDinamica<TElem>::esFin( ) {
		 
       return _ant -> sig( ) == 0;
		 
     };


     template <class TElem>
     bool TSecuenciaDinamica<TElem>::esVacio( ) {
		 
       return _pri -> sig( ) == 0;
		 
     };


  // Operaciones de entrada/salida

     template <class TElem>
     void TSecuenciaDinamica<TElem>::escribe( ) {
		 
	   cout << endl;
		 
       if ( _pri == _ant ) cout << "<--" << endl;
		 
       TNodoSecuencia<TElem>* tmp = _pri -> sig( );
		 
       while ( tmp != 0 ) {
		   
         cout << tmp -> elem( ) << endl;
		   
         if ( tmp == _ant ) cout << "<--" << endl;
		   
         tmp = tmp -> sig( );
		   
       }
		 
	   cout << endl;
		 
     };

     

#endif