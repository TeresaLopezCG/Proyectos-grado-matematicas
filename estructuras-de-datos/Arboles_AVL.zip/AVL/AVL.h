#ifndef arbusH
#define arbusH


#include <iostream>


#include "secuencia_dinamica.h"


// Excepciones nuevas generadas por las operaciones de este TAD:
// Acceso cuando se accede con una clave que no esta en el arbol
// class EClaveErronea { };


using namespace std;


// El tipo 'TClave' debe implementar:
//    operator==
//    operator<
//    operator>



template <class TClave, class TValor>
class TArbus;



template <class TClave, class TValor>
class TNodoArbus {
	
  private:
	
    TClave _clave;
    TValor _valor;
	
    TNodoArbus<TClave,TValor> *_iz, *_dr;
    
    int _altura; // altura del subarbol (hoja = 1, vacio = 0)
	
    TNodoArbus( TClave, TValor, TNodoArbus<TClave,TValor>*, TNodoArbus<TClave,TValor>* );
	
  public:
	
    TClave clave();
    TValor valor();
	
    TNodoArbus<TClave,TValor>* iz();
    TNodoArbus<TClave,TValor>* dr();
	
    friend class TArbus<TClave,TValor>;
	
};



template <class TClave, class TValor>
class TArbus {
	
	
  public:

	
  // Constructoras
	
     TArbus( );
     TArbus( TArbus<TClave,TValor>& );
    

  // Operaciones de los arboles de busqueda
	
     void inserta( TClave, TValor );
     // Pre  : true
     // Post : inserta un par (clave,valor) en el arbol
	 //        si la clave ya esta en el arbol, se sustituye el valor antiguo por el nuevo

     void borra( TClave );
     // Pre  : true
     // Post : elimina un par (clave,valor) del arbol a partir de una clave dada
     //        si la clave no esta, el arbol no se modifica

     TValor consulta( TClave ); // throw ( EClaveErronea );
     // Pre  : esta( clave )
     // Post : devuelve el valor asociado con la clave dada
     // Lanza la excepcion 'EClaveErronea' si el arbol no contiene dicha clave

     bool esta( TClave );
     // Pre  : true
     // Post : devuelve true o false segun si el arbol contiene o no la clave

     bool esVacio( );
     // Pre: true
     // Post: Devuelve true o false segun si el arbol esta o no vacio

	
  // Recorridos 
	
	 TSecuenciaDinamica<TValor> recorre( );
	 // Pre  : true
	 // Post : devuelve los valores del arbol, ordenados por la clave
	
	 TSecuenciaDinamica<TClave> recorreClave( );
	 // Pre  : true
	 // Post : devuelve las claves del arbol ordenadas
	
	
  // Escritura
	
     void escribe( );
    
	 
  // AVL

     int altura( ); 
	 // altura del arbol; 
	 // O(1)
     
     bool esAVL( ); 
	 // comprueba las alturas y el equilibrio; 
	 // O(n)

	
	
  private:

	
  // Variables privadas
	
     TNodoArbus<TClave,TValor>* _ra;
	
  // operacion privada de escritura
	
     void escribeAux( TNodoArbus<TClave, TValor>*, string );
	
  // operaciones auxiliares para los algoritmos recursivos
  
     TNodoArbus<TClave,TValor>* busca( TClave, TNodoArbus<TClave, TValor>* );
	
     void insertaAux( TClave, TValor, TNodoArbus<TClave, TValor>* &  );
     void borraAux( TClave, TNodoArbus<TClave,TValor>* & );
     void borraRaiz( TNodoArbus<TClave,TValor>* & );
     void borraConMin( TNodoArbus<TClave,TValor>* &, TNodoArbus<TClave,TValor>* & );

  // Operaciones privadas AVL
     
     int alturaNodo( TNodoArbus<TClave,TValor>* );
     void actualizaAltura( TNodoArbus<TClave,TValor>* );
     int factorEquilibrio( TNodoArbus<TClave,TValor>* );
     void rotacionDerecha( TNodoArbus<TClave,TValor>* & );
     void rotacionIzquierda( TNodoArbus<TClave,TValor>* & );
     void equilibra( TNodoArbus<TClave,TValor>* & );
     bool compruebaAVL( TNodoArbus<TClave,TValor>*, int & );
     TNodoArbus<TClave,TValor>* copiaAux( TNodoArbus<TClave,TValor>* );
	 
	
};



//---------------------------------------------------------------------------
//                              IMPLEMENTACION
//---------------------------------------------------------------------------



  // Clase de los nodos del arbol de busqueda


    template <class TClave, class TValor>
    TNodoArbus<TClave,TValor>::TNodoArbus( TClave clave, TValor valor, 
										   TNodoArbus<TClave,TValor>* iz, 
										   TNodoArbus<TClave,TValor>* dr ) :
										   	
      _clave(clave), _valor(valor), _iz(iz), _dr(dr), _altura(1) {
      	
    };


    template <class TClave, class TValor>
    TClave TNodoArbus<TClave,TValor>::clave( ) {
		
      return _clave;
		
    }


    template <class TClave, class TValor>
    TValor TNodoArbus<TClave,TValor>::valor( ) {
		
      return _valor;
		
    }


    template <class TClave, class TValor>
    TNodoArbus<TClave,TValor>* TNodoArbus<TClave,TValor>::iz( ) {
		
      return _iz;
		
    }


    template <class TClave, class TValor>
    TNodoArbus<TClave,TValor>* TNodoArbus<TClave,TValor>::dr( ) {
		
      return _dr;
		
    }



  // Constructoras de la clase de arboles de busqueda
  

     template <class TClave, class TValor>
     TArbus<TClave,TValor>::TArbus( ) :
     	
       _ra( 0 ) {
       	
     };



  // Operaciones de los arboles binarios de busqueda equilibrados en altura (AVL)


      // INSERCION AVL
      // Pre: true.
      // Post: inserta (clave,valor); si existe, actualiza su valor.
      //       El arbol sigue siendo un ABB equilibrado en altura.
      // Tiempo: O(log n); espacio auxiliar (pila): O(log n).
      
      
      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::inserta( TClave clave, TValor valor ) {
      	
        insertaAux( clave, valor, _ra );
        
      }
      

      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::insertaAux( TClave clave, TValor valor,
                                              TNodoArbus<TClave,TValor>* & p ) {
                                              	
        if ( p == 0 ) p = new TNodoArbus<TClave,TValor>( clave, valor, 0, 0 );
        else if ( clave == p -> _clave ) p -> _valor = valor;
             else {
        	
          		if ( clave < p -> _clave ) insertaAux( clave, valor, p -> _iz );
          		else insertaAux( clave, valor, p -> _dr );
          
          		equilibra( p );
          
        	}
        
      }



      // BORRADO AVL
      // Pre: true.
      // Post: elimina la clave, si existe; en otro caso no modifica el arbol.
      //       Se mantiene el equilibrio AVL.
      // Tiempo: O(log n); espacio auxiliar (pila): O(log n).
      
      
      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::borra( TClave clave ) {
      	
        borraAux( clave, _ra );
        
      }


      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::borraAux( TClave clave,
                                            TNodoArbus<TClave,TValor>* & p ) {
                                            	
        if ( p != 0 ) {
        	
          if ( clave == p -> _clave ) borraRaiz( p );
          else if ( clave < p -> _clave ) borraAux( clave, p -> _iz );
               else borraAux( clave, p -> _dr );
               
          if ( p != 0 ) equilibra( p );
          
        }
        
      }


      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::borraRaiz( TNodoArbus<TClave,TValor>* & p ) {
      	
        TNodoArbus<TClave,TValor>* aux;
        
        if ( p -> _iz == 0 ) {
        	
          aux = p;
          p   = p -> _dr;
          
          delete aux;
          
        }
        else if ( p -> _dr == 0 ) {
        	
          		aux = p;
          		p   = p -> _iz;
          
          		delete aux;
          
             }
        	 else borraConMin( p, p -> _dr );
        
      }


      // Sustituye la pareja de p por el minimo del subarbol q y lo elimina.
      // Reequilibra cada nodo del camino de retorno.
      
      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::borraConMin( TNodoArbus<TClave,TValor>* & p,
                                               TNodoArbus<TClave,TValor>* & q ) {
                                               	
        if ( q -> _iz != 0 ) {
        	
          borraConMin( p, q -> _iz );
          
          equilibra( q );
          
        }
        else {
        	
          p -> _clave = q -> _clave;
          p -> _valor = q -> _valor;
          
          TNodoArbus<TClave,TValor>* aux = q;
          
          q = q -> _dr;
          
          delete aux;
          
        }
        
      }



      // ALTURAS Y ROTACIONES AVL
      
      
      template <class TClave, class TValor>
      int TArbus<TClave,TValor>::alturaNodo( TNodoArbus<TClave,TValor>* p ) {
      	
        return p == 0 ? 0 : p -> _altura;
        
      }


      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::actualizaAltura( TNodoArbus<TClave,TValor>* p ) {
      	
        int iz = alturaNodo( p -> _iz );
        int dr = alturaNodo( p -> _dr );
        
        p -> _altura = 1 + ( iz > dr ? iz : dr );
        
      }
      

      template <class TClave, class TValor>
      int TArbus<TClave,TValor>::factorEquilibrio( TNodoArbus<TClave,TValor>* p ) {
      	
        return alturaNodo( p -> _iz ) - alturaNodo( p -> _dr );
        
      }



      // Rotacion simple a derecha (caso LL; tambien paso final del caso LR).
      
      
      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::rotacionDerecha( TNodoArbus<TClave,TValor>* & p ) {
      	
        TNodoArbus<TClave,TValor>* q = p -> _iz;
        
        p -> _iz = q -> _dr;
        q -> _dr = p;
        
        actualizaAltura( p );
        actualizaAltura( q );
        
        p = q;
        
      }



      // Rotacion simple a izquierda (caso RR; tambien paso final del caso RL).
      
      
      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::rotacionIzquierda( TNodoArbus<TClave,TValor>* & p ) {
      	
        TNodoArbus<TClave,TValor>* q = p -> _dr;
        
        p -> _dr = q -> _iz;
        q -> _iz = p;
        
        actualizaAltura( p );
        actualizaAltura( q );
        
        p = q;
        
      }



      // Casos LL, RR, LR y RL. Cada llamada cuesta O(1).
      
      
      template <class TClave, class TValor>
      void TArbus<TClave,TValor>::equilibra( TNodoArbus<TClave,TValor>* & p ) {
      	
        if ( p == 0 ) return;
        
        actualizaAltura( p );
        
        if ( factorEquilibrio( p ) > 1 ) {
        	
          if ( factorEquilibrio( p -> _iz ) < 0 ) rotacionIzquierda( p -> _iz ); // LR
          
          rotacionDerecha( p );           // LL o LR
          
        }
        else if ( factorEquilibrio( p ) < -1 ) {
        	
          if ( factorEquilibrio( p -> _dr ) > 0 ) rotacionDerecha( p -> _dr );  // RL
          
          rotacionIzquierda( p );         // RR o RL
          
        }
        
      }
      


      // Diagnostico para pruebas: comprueba alturas almacenadas y FE.
      
      
      template <class TClave, class TValor>
      bool TArbus<TClave,TValor>::compruebaAVL( TNodoArbus<TClave,TValor>* p, int & h ) {
      	
        if ( p == 0 ) { 
		
				h = 0; 
				
				return true; 
				
		}
		
        int hi, hd;
        
        bool bi = compruebaAVL( p -> _iz, hi );
        bool bd = compruebaAVL( p -> _dr, hd );
        
        h = 1 + ( hi > hd ? hi : hd );
        
        return bi && bd && p -> _altura == h && hi - hd <= 1 && hd - hi <= 1;
        
      }


      template <class TClave, class TValor>
      int TArbus<TClave,TValor>::altura( ) { 
	  
	  		return alturaNodo( _ra ); 
			  
	  }


      template <class TClave, class TValor>
      bool TArbus<TClave,TValor>::esAVL( ) {
      	
        int h;
        
        return compruebaAVL( _ra, h );
        
      }



      // Constructor de copia: evita compartir nodos entre arboles.
      
      
      template <class TClave, class TValor>
      TNodoArbus<TClave,TValor>* TArbus<TClave,TValor>::copiaAux( TNodoArbus<TClave,TValor>* p ) {
                                                    	
        if ( p == 0 ) return 0;
        
        TNodoArbus<TClave,TValor>* q = new TNodoArbus<TClave,TValor>(p->_clave,p->_valor,0,0);
        
        q -> _altura = p -> _altura;
        q -> _iz     = copiaAux(p->_iz);
        q -> _dr     = copiaAux(p->_dr);
        
        return q;
        
      }


      template <class TClave, class TValor>
      TArbus<TClave,TValor>::TArbus( TArbus<TClave,TValor>& a ) : _ra(0) {
      	
        _ra = copiaAux(a._ra);
        
      }



  // Consultas


     template <class TClave, class TValor>
     TValor TArbus<TClave,TValor>::consulta( TClave clave ) // throw ( EClaveErronea ) 
	 {
		 
       TNodoArbus<TClave,TValor>* aux;

       aux = busca(clave, _ra);
		 
       if ( aux == 0 )
		   
         throw EClaveErronea( "Error: el arbol no contiene la clave" );
		 
       else
		   
         return aux -> valor( );
		 
     };


     template <class TClave, class TValor>
     bool TArbus<TClave,TValor>::esta( TClave clave ) {
		 
       return busca(clave, _ra) != 0;
		 
     };


     template <class TClave, class TValor>
     TNodoArbus<TClave,TValor>* TArbus<TClave,TValor>::busca( TClave clave, TNodoArbus<TClave,TValor>* p ) {
		 
       TNodoArbus<TClave,TValor>* r;

       if ( p == 0 )
		   
         r = 0;
		 
       else if ( clave == p -> clave( ) )
		   
         r = p;
		 
       else if ( clave < p -> clave( ) )
		   
         r = busca( clave, p -> iz( ) );
		 
       else
		   
         r = busca( clave, p -> dr( ) );
		 
       return r;
		 
     };


     template <class TClave, class TValor>
     bool TArbus<TClave,TValor>::esVacio( ) {
		 
       return _ra == 0;
		 
     };



  // Recorridos
  

     template <class TClave, class TValor>
     void inOrdAcu( TNodoArbus<TClave,TValor>* p, TSecuenciaDinamica<TValor>& xs ) {
		 
       if ( p != 0 ) {
		   
         inOrdAcu( p -> iz( ), xs );
		   
         xs.inserta( p -> valor( ) );
		   
         inOrdAcu( p -> dr( ), xs );
		   
       }
		 
     };


     template <class TClave, class TValor>
     TSecuenciaDinamica<TValor> TArbus<TClave,TValor>::recorre( ) {
		 
       TSecuenciaDinamica<TValor> r;

       inOrdAcu( _ra, r );
		 
       return r;
		 
     };


     template <class TClave, class TValor>
     void inOrdAcuClave( TNodoArbus<TClave,TValor>* p, TSecuenciaDinamica<TClave>& xs ) {
		 
       if ( p != 0 ) {
		   
         inOrdAcuClave( p -> iz( ), xs );
		   
         xs.inserta( p -> clave( ) );
		   
         inOrdAcuClave( p -> dr( ), xs );
		   
       }
		 
     };


     template <class TClave, class TValor>
     TSecuenciaDinamica<TClave> TArbus<TClave,TValor>::recorreClave( ) {
		 
       TSecuenciaDinamica<TClave> r;

       inOrdAcuClave( _ra, r );
		 
       return r;
		 
     };

 

  // Operaciones de escritura de arboles binarios de busqueda


     template <class TClave, class TValor>
     void TArbus<TClave,TValor>::escribeAux( TNodoArbus<TClave,TValor>* p, string prefijo ) {
		 
       if ( p != 0 ) {
		   
         cout << ( prefijo + " : " ) << "(" << p -> clave( ) << "," << p -> valor( ) << ")" << " [h=" << p -> _altura << ", FE=" << factorEquilibrio(p) << "]" << endl;
		   
         escribeAux( p -> iz( ), prefijo + ".1" );
         escribeAux( p -> dr( ), prefijo + ".2" );
		   
       }
		 
     }


     template <class TClave, class TValor>
     void TArbus<TClave,TValor>::escribe( ) {
		 
	   cout << endl;
		 
       escribeAux( _ra, "1" );
		 
     };



#endif