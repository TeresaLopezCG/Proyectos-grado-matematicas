#include <iostream>
#include <cassert>


#include "AVL.h"


using namespace std;



void pruebaRotacion(const char* nombre, int a, int b, int c) {
	
    TArbus<int,char> arbol;
    
    arbol.inserta(a,'a');
    arbol.inserta(b,'b');
    arbol.inserta(c,'c');
    
    cout << "\nRotacion " << nombre << ":" << endl;
    arbol.escribe();
    
    assert(arbol.esAVL() && arbol.altura() == 2);
    
    TSecuenciaDinamica<int> xs = arbol.recorreClave();
    
    xs.reinicia();
    
    assert(xs.actual() == 10); 
	xs.avanza();
	
    assert(xs.actual() == 20); 
	xs.avanza();
	
    assert(xs.actual() == 30); 
	xs.avanza();
	
    assert(xs.esFin());
    
}



int main() {
	
    // Pruebas de los cuatro tipos de rotacion:
    
    pruebaRotacion("LL",30,20,10);
    pruebaRotacion("RR",10,20,30);
    pruebaRotacion("LR",30,10,20);
    pruebaRotacion("RL",10,30,20);

    // Se mantienen las operaciones publicas del ABB original:
    
    TArbus<int,char> arbol;
    
    int  claves[]  = {7,5,9,3,4,6};
    char valores[] = {'a','b','c','d','e','f'};
    
    for (int i=0;i<6;i++) {
    	
        arbol.inserta(claves[i],valores[i]);
        assert(arbol.esAVL());
        
    }
    
    cout << "\nAVL con las parejas del main original:" << endl;
    arbol.escribe();
    
    assert(!arbol.esVacio() && arbol.esta(4) && !arbol.esta(12));
    assert(arbol.consulta(7)=='a');
    
    arbol.inserta(7,'z');
    arbol.inserta(4,'v');
    
    assert(arbol.consulta(7)=='z' && arbol.consulta(4)=='v');
    assert(arbol.esAVL());

    cout << "\nClaves en orden:" << endl;
    TSecuenciaDinamica<int> secClaves = arbol.recorreClave();
    secClaves.escribe();
    
    cout << "Valores ordenados por clave:" << endl;
    TSecuenciaDinamica<char> secValores = arbol.recorre();
    secValores.escribe();

    // Borrados, incluso raiz, clave inexistente y arbol vacio.
    
    int borrados[] = {5,7,3,9,4,6,123};
    
    for (int i=0;i<7;i++) {
    	
        arbol.borra(borrados[i]);
        assert(arbol.esAVL());
        cout << "Tras borrar " << borrados[i] << ": altura=" << arbol.altura() << endl;
        
    }
    
    assert(arbol.esVacio());

    // Insercion ordenada: un ABB ordinario degeneraria en una cadena.
    
    TArbus<int,int> grande;
    
    for (int i=1;i<=1000;i++) {
    	
        grande.inserta(i,10*i);
        assert(grande.esAVL());
        
    }
    
    assert(grande.altura() <= 11);
    
    for (int i=1;i<=1000;i+=2) {
    	
        grande.borra(i);
        assert(grande.esAVL());
        
    }
    
    assert(grande.consulta(1000)==10000);
    
    cout << "\n1000 inserciones ordenadas y 500 borrados: AVL correcto, altura="
         << grande.altura() << endl;

    // Prueba de la excepcion original.
    
    try { 
	
		arbol.consulta(999); 
		assert(false); 
		
	}
    catch (EClaveErronea e) { 
	
		cout << "Excepcion esperada: " << e.mensaje() << endl; 
		
	}
	
    cout << "\nTodas las pruebas superadas." << endl;
    
    return 0;
    
}